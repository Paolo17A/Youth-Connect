package com.example.ywda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
